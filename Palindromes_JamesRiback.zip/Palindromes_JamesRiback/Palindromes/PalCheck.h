#ifndef PALCHECK_H
#define PALCHECK_H
#include <string>
#include "Queue.h"
/* ====== Class PALCHECK ========*/
//checks for palindromes in a queue
class PalCheck {
public:
	bool PalCheck::isPalindrome(Queue<char> pq);
};
#endif